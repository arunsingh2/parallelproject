package com.cg.banking.client;
import java.util.Random;
import java.util.Scanner;

import org.omg.PortableServer.IMPLICIT_ACTIVATION_POLICY_ID;

import com.cg.account.beans.Account;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidPinNumberExcepition;
import com.cg.banking.services.BankingServiceImpl;
import com.cg.banking.util.BankingDBUtil;
public class MainClass {
	BankingServiceImpl impl =  new BankingServiceImpl();


	public void createAccount() {
		String SctransType;
		System.out.println("Welcome to abc bank");
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your name");
		String Scname = sc.next();
		System.out.println("Enter your address");
		String Scaddr=sc.next();
		System.out.println("Enter your adhaar number");
		String Scadhar=sc.next();
		System.out.println("Enter your phone number");
		String Scphone=sc.next();
		System.out.println("Enter your pan number");
		String Scpan = sc.next();
		System.out.println("Enter ifsc code");
		String Scifsc = sc.next();
		System.out.println("Enter account type(Savings/Current)");
		String ScaccType = sc.next();

		SctransType = "Deposite";
		System.out.println("Enter initial pin as per your choice");
		int Scpin = sc.nextInt();

		System.out.println("enter initial amount you want to be deposited");
		float Scamount = sc.nextFloat();


		Account acct =	impl.createAccount(Scname, Scaddr, Scadhar,Scphone,Scpan, Scifsc, ScaccType, Scpin, Scamount, SctransType);
		System.out.println(acct);


		System.out.println("***Congratulations your account has been created  with account number: "+acct.getAccountNum());


	}
	public void depositMoney()
	{
		Scanner sc =new Scanner(System.in);
		String AccountNum;
		System.out.println("Enter account number");
		AccountNum=sc.next();
		if(AccountNum==null)
		{
			throw new InvalidAccountTypeException("invalid account number");
		}
		System.out.println("Enter amount to be deposited");
		float amoun = sc.nextFloat();
		String tType="Deposite";

		float mny=impl.depositAmount(AccountNum, amoun, tType);
		//System.out.println("Successful transaction"+mny);
		System.out.println("amount has been depostied"+mny);


	}
	public void withdrawMoney()
	{Scanner sc =new Scanner(System.in);

	String accNum;
	System.out.println("Enter account number");
	accNum=sc.next();
	System.out.println("Enter amount to be withdrawn");
	float amount = sc.nextFloat();
	int pinN;
	System.out.println("Enter pinNo");
	pinN= sc.nextInt();
	float mny= impl.withdrawAmount(accNum, amount, pinN);
	System.out.println("Successful transaction"+mny);


	}
	public void changePin()
	{Scanner sc = new Scanner(System.in);
	String accountNum;
	System.out.println("Enter account number");
	accountNum= sc.next();
	System.out.println("Enter your current pin number");
	int aPin;
	aPin=sc.nextInt();
	int bPin;
	System.out.println("Enter your new pin number");
	bPin= sc.nextInt();
	System.out.println(impl.changePin(accountNum, aPin, bPin));
	}
	public void fundTransfr()
	{
		Scanner sc = new Scanner(System.in);
		String accountNumTo;
		String accountNumFrom;
		float transAm;
		int pinNum;
		//System.out.println("Enter account");
		//pinNum= sc.nextInt();
		
		//accountNumTo= sc.next();
		System.out.println("Enter  accountNumber of sender");
		accountNumFrom= sc.next();
		System.out.println("Enter pin Number of from");
		pinNum= sc.nextInt();
		System.out.println("Enter account Number of  receiver");
		accountNumTo= sc.next();
		System.out.println("Enter amount to be transferred");
		transAm= sc.nextFloat();
		impl.fundTransfer(accountNumTo, accountNumFrom, transAm, pinNum);
		System.out.println("Successful transaction");

	}
	public void getDetai()
	{Scanner sc = new Scanner(System.in);
	String accountNum;
	int pinNum;
	System.out.println("Enter account number");
	accountNum=sc.next();
	System.out.println("Enter pin number");
	pinNum=sc.nextInt();


	System.out.println(impl.getAccountDetails(accountNum, pinNum));
	
	}
	@SuppressWarnings("unlikely-arg-type")
	public void getAllDetai()
	{System.out.println("Enter admin pin");
	Scanner sc = new Scanner(System.in);
	String pin = sc.next();
	if(!pin.equals(BankingDBUtil.PIN))
	{
		throw new InvalidPinNumberExcepition("Invalid admin pin");
	}


	System.out.println("your all account details are");
	System.out.println(impl.getAllAccountDetails());

	}
	/*public void getTransStatement()
	{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter account number");
		String accNum= sc.next();
		System.out.println("Enter Pin");
		int piN=sc.nextInt();
		System.out.println(impl.getTrans);
	}*/
	public static void main(String args[])
	{

		Scanner sc= new Scanner(System.in);
		MainClass mc=new MainClass();
		int trans;
		while(true)
		{
			System.out.println("Enter 1:create account"+
					"Enter 2: deposit money"+
					"Enter 3 :  withdraw money"+
					"Enter 4:fund transfer"+
					"Enter 5:see account details"+
					"Enter 6 :see all account details"+
					"Enter 7:change pin number"+
					"Enter 8:exit");
			trans= sc.nextInt();
			if(trans==1)
			{
				mc.createAccount();

			}
			if(trans==2)
			{
				mc.depositMoney();

			}
			if(trans==3)
			{
				mc.withdrawMoney();
			}
			if(trans==4)
			{mc.fundTransfr();

			}
			if(trans==5)
			{mc.getDetai();
			
			}
			if(trans==6)
			{mc.getAllDetai();

			}
			if(trans==7)
			{
				mc.changePin();

			}
	
			if(

					trans==8)
			{
				System.exit(trans);
			}
		
			
			trans++;
			System.out.println(                   );

		}
	}}

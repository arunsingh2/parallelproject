package com.cg.banking.util;
import java.util.HashMap;

import com.cg.account.beans.Account;


public class BankingDBUtil {
	public static   String PIN="321";
	public static HashMap<Integer, Account> accounts = new HashMap<>();
	public  static int  ACCOUNT_NO_COUNTER=100;
	public static int  getACCOUNT_NO_COUNTER() {
		return++ACCOUNT_NO_COUNTER;
	
	}
}



package com.cg.banking.services;

import java.util.List;

import javax.security.auth.login.AccountNotFoundException;

import com.cg.account.beans.*;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotfoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberExcepition;


public interface BankingServices  {
	Account createAccount(String name,String address,String adhaar,String phone,String pan,String ifsc,String accountType, int pin,
			float amount,String transactionType)
	throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException;
	
	
		
	float depositAmount(String accountNo, float amount,String transType)
	
			throws 
			AccountNotfoundException,BankingServicesDownException,AccountBlockedException;
			
	float withdrawAmount(String  accountNo,float amount, int pinNo)
	throws InsufficientAmountException,AccountNotfoundException,InvalidPinNumberExcepition,BankingServicesDownException,AccountBlockedException;
	
	
	boolean fundTransfer(String accountNoTo, String  accountNoFrom,float transferAmount,int pinNo)
	throws InsufficientAmountException,AccountNotfoundException,InvalidPinNumberExcepition,
	BankingServicesDownException,AccountBlockedException;
	
	
Account  getAccountDetails(String accountNo,int pin)
	throws AccountNotfoundException,BankingServicesDownException;
	
	boolean changePin(String accountNo, int aPin ,int bPin)
	throws InvalidAmountException,InvalidAccountTypeException,BankingServicesDownException;
	List<Account> getAllAccountDetails()
	throws BankingServicesDownException,
	AccountNotfoundException;



}


package com.cg.banking.services;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import javax.security.auth.login.AccountNotFoundException;

import com.cg.account.beans.Account;
import com.cg.account.beans.Customer;
import com.cg.account.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotfoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberExcepition;
import com.cg.banking.servicesDao.BankingServiceDAOImpl;
import com.cg.banking.servicesDao.BankingServiceTransactionDaoImpl;
import com.cg.banking.servicesDao.BankingServicesDAO;

public
class BankingServiceImpl  implements BankingServices{

	private BankingServicesDAO bankingDao = new BankingServiceDAOImpl();
	private BankingServicesDAO bankingDaoo = new BankingServiceDAOImpl();
	private   BankingServiceTransactionDaoImpl  bankingDao1=new BankingServiceTransactionDaoImpl(); 
	private   BankingServiceTransactionDaoImpl  bankingDao11=new BankingServiceTransactionDaoImpl();   
	Scanner sc=new Scanner(System.in);
	@Override
	public Account createAccount(String name, String address, String adhaar, String phone, String pan, String ifsc,
			String accountType, int pin,float amount, String transactionType)
					throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {

		if(!(accountType.equalsIgnoreCase("Savings")||accountType.equalsIgnoreCase("Current")))

			throw new InvalidAccountTypeException("Invalid account type exception");

		Customer customer = new Customer(name, address, adhaar, phone);

		Transaction transaction = new Transaction(amount, transactionType);

		Account account = new Account(ifsc,accountType,pin,customer,transaction,"Working");


		Account accou = bankingDao.save(account);

		return accou;

	}

	public float depositAmount(String accountNo, float amount, String transType)
			throws AccountNotfoundException, BankingServicesDownException, AccountBlockedException {
		Account acc = bankingDao.findOne(accountNo);
		try {
			if(acc==null)
		
				throw new AccountNotFoundException();
			if(amount<1)
				throw new InvalidAmountException();
			
			if(acc.getAccountStatus().equals("Account Blocked"))

					throw new AccountBlockedException();
			}
			catch( AccountNotFoundException e1)
			{
				System.out.println(e1+":account not found");
			}
		catch(  InvalidAmountException e2)
		{
			System.out.println(e2+":can not draw this much amount");
		}
		catch( AccountBlockedException  e3)
		{
			System.out.println(e3+":account is blocked");
		}
		//System.out.println(acc);
		Transaction trr = new Transaction(acc.getTransactions().getTransactionId(),(acc.getTransactions().getAmount()+amount),transType);
		acc.setTransactions(trr);
		trr.setTransactionId();

		boolean flag = bankingDao.update(acc);
		
		if(!flag)

			throw new BankingServicesDownException("Transaction can not be complete");
		bankingDao1.save(acc);
		return acc.getTransactions().getAmount();
	}

	@Override
	public float withdrawAmount(String accountNo, float amount, int pin)
			throws InsufficientAmountException, AccountNotfoundException, InvalidPinNumberExcepition,
			BankingServicesDownException, AccountBlockedException {
		Account acc = bankingDao.findOne(accountNo);
	try {
		if(acc==null)
	
			throw new AccountNotFoundException();
		if(amount<1)
			throw new InvalidAmountException();
		
		if(acc.getAccountStatus().equals("Account Blocked"))

				throw new AccountBlockedException();
		}
		catch( AccountNotFoundException e1)
		{
			System.out.println(e1+"   "+":account not found");
		}
	catch(  InvalidAmountException e2)
	{
		System.out.println(e2+"   "+":can not draw this much amount");
	}
	catch( AccountBlockedException  e3)
	{
		System.out.println(e3+"   "+":account is blocked");
	}

	
			for(int i=0;i<4;i++)
			{
				if(acc.getaPIN()==pin)
					break;
				if(acc.getaPIN()!=pin)
					System.out.println("pin number is invalid please enter again");
				 // break;
				if(i==3&&acc.getaPIN()!=pin) 
					acc.setAccountStatus("Account Blocked");
				bankingDao.update(acc);

				throw new AccountBlockedException("Account is blocked transaction can not be completed");
		
		}
		//System.out.println(acc.getTransactions().getAmount());
		Transaction trr = new Transaction(acc.getTransactions().getTransactionId(),(acc.getTransactions().getAmount()-amount),"Normal");
		acc.setTransactions(trr);
		boolean flag = bankingDao.update(acc);

		if(!flag)

			throw new BankingServicesDownException("Transaction can not be complete");
		bankingDao1.save(acc);
	//	if(acc.getaPIN()==pin) 
		  return acc.getTransactions().getAmount();
		}
	

	@Override
	public boolean fundTransfer(String accountNoTo, String accountNoFrom, float transferAmount, int pinNo)
			throws InsufficientAmountException, AccountNotfoundException, InvalidPinNumberExcepition,
			BankingServicesDownException, AccountBlockedException {
		Account acc= bankingDao.findOne(accountNoTo);		
		//System.out.println(acc.getTransactions().getAmount());
			try {
			if(acc.getAccountStatus().contentEquals("Account Blocked"))
				throw new AccountBlockedException("Account is blocked");}
		catch(AccountBlockedException e) {
			System.out.println(e);
		}
		if(acc.getaPIN()!=pinNo)

			for(int i=0;i<3;i++) {
				if(acc.getaPIN()==pinNo) 
					break;
				if(acc.getaPIN()!=pinNo)
					System.out.println("your pin is invalid please enter again");
				if(i==2&&acc.getaPIN()!=pinNo)
				{
					acc.setAccountStatus("AccountBlocked");
				}
				{
					System.out.println("pin number is invalid please enter again");


					throw new InvalidPinNumberExcepition("Account  is Blocked");}
			}
		Transaction trr = new Transaction(Integer.parseInt(accountNoTo),(acc.getTransactions().getAmount()+transferAmount),  "Normal");
		acc.setTransactions(trr);
		trr.setTransactionId();
		bankingDao.update(acc);
		System.out.println(acc.getTransactions().getAmount());
		boolean flag = bankingDao.update(acc);
		//System.out.println("senders bal"+acc.getTransactions().getAmount());
		if(!flag)

			throw new BankingServicesDownException("Transaction can not be complete");
		bankingDao1.save(acc);

		Account acc1= bankingDao.findOne(accountNoFrom);		

		Transaction trr1 = new Transaction(acc1.getTransactions().getTransactionId(),(acc1.getTransactions().getAmount()+(-transferAmount)),  "Normal");

		acc1.setTransactions(trr1);
		trr1.setTransactionId();
		bankingDaoo.update(acc1);
		System.out.println(acc1.getTransactions().getAmount());
		boolean flag1= bankingDaoo.update(acc1);
		if(!flag1)

			throw new BankingServicesDownException("Transaction can not complete");

		bankingDao11.save(acc1);

		return true;
	}



	public  Account  getAccountDetails(String accountNo, int pin)
			throws AccountNotfoundException, BankingServicesDownException,InvalidPinNumberExcepition {
		// TODO Auto-generated method stub
		Account acc = bankingDao.findOne(accountNo);
		//System.out.println("balance is "+acc.getTransactions().getAmount());



			if(acc.getAccountStatus().equals("Account Blocked"))
			throw new AccountBlockedException("Account is Blocked");
		else
		{

			for(int i=0;i<3;i++) {
				if(acc.getaPIN()==pin) 
					break;
				if(acc.getaPIN()!=pin)
					System.out.println("your pin is invalid please enter again");
				if(i==2&&acc.getaPIN()!=pin)
				{
					acc.setAccountStatus("AccountBlocked");
					throw new InvalidPinNumberExcepition("Account  is Blocked");
				}

			}

		}
		return acc;
	}


	@Override
	public List<Account> getAllAccountDetails() throws BankingServicesDownException, AccountNotfoundException {
		// TODO Auto-generated method stub
		return bankingDao.findAll();
	}

	@Override
	public boolean changePin(String accountNo, int aPin, int bPin)
			throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException {
		Account  acc = bankingDao.findOne(accountNo);	
		if(acc.getAccountStatus().equals("Account Blocked"))
			throw new AccountBlockedException("Account is Blocked");
		else
			if(acc.getaPIN()!=aPin)
				for(int i=0;i<3;i++) {
					if(acc.getaPIN()!=aPin) 
						break;
					if(acc.getaPIN()!=aPin)
						System.out.println("your pin is invalid please enter again");
					if(i==2&&acc.getaPIN()!=aPin)
					{
						acc.setAccountStatus("AccountBlocked");
						throw new InvalidPinNumberExcepition("Account  is Blocked");
					}

				}

		return true;
	}
}



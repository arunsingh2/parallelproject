package com.cg.banking.servicesDao;

import java.util.HashMap;
import java.util.List;

import com.cg.account.beans.Account;



public class BankingServiceTransactionDaoImpl implements BankingServicesDAO {
//HashMap<>hs = new HashMap<>();

	@Override
	public Account save(Account account) {
		int tId=(account.getTransactions()).getTransactionId();
		account.transStatements.put(tId,account.getTransactions());
		return account;
	}

	@Override
	public boolean update(Account account) {
		
		return false;
	}

	@Override
	public Account findOne(String accountNum) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Account> findAll() {
		// TODO Auto-generated method stub
		return null;
	}

	
	
	}



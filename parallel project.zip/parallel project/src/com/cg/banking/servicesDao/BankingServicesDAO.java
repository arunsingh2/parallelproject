package com.cg.banking.servicesDao;

import java.util.List;

import com.cg.account.beans.Account;

public interface BankingServicesDAO {
	Account save(Account account);
	boolean update(Account account);
	Account findOne(String accountNum);
	
	List<Account> findAll();

}

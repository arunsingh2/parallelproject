package com.cg.banking.servicesDao;

import java.util.ArrayList;
import java.util.List;

import com.cg.account.beans.Account;
import com.cg.banking.util.BankingDBUtil;


public class BankingServiceDAOImpl  implements BankingServicesDAO{

	@Override
	public Account save(Account account) {
	
	account.setAccountNum(Integer.toString((BankingDBUtil.getACCOUNT_NO_COUNTER())));
	BankingDBUtil.accounts.put(Integer.parseInt(account.getAccountNum()),account);
	
return account;
	
	}

	@Override
	public boolean update(Account account) {
		
		BankingDBUtil.accounts.put(Integer.parseInt(account.getAccountNum()),account);
		return true;
	

	}

	@Override
	public Account findOne(String accountNum) {
	return BankingDBUtil.accounts.get(Integer.parseInt(accountNum));
	
	}

	@Override
	public List<Account> findAll() {
		ArrayList<Account> accountList = new ArrayList<>(BankingDBUtil.accounts.values());
		return accountList;
	}

	

}

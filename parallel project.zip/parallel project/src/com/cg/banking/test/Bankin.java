package com.cg.banking.test;

import static org.junit.Assert.*;

import javax.security.auth.login.AccountNotFoundException;

import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.account.beans.Account;
import com.cg.account.beans.Customer;
import com.cg.account.beans.Transaction;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidPinNumberExcepition;
import com.cg.banking.services.BankingServiceImpl;
import com.cg.banking.services.BankingServices;
import com.cg.banking.util.BankingDBUtil;



public class Bankin {
	private static BankingServices bankingservices;

	@BeforeClass
	public static void setUpTestEnv()
	{
		bankingservices = new BankingServiceImpl();
	}
	@Before
	public void setUpTestData()
	{
		Account acc1= new Account("10010","001","Savings",1,new Customer("Arun", "beswn", "123456781122", "8823234211"),new Transaction(1001, 400, "Deposite"),"Working");
		Account acc2= new Account("10011","003","Savings",2,new Customer("Anil", "jharkhand", "123456781122", "8823234211"),new Transaction(1002, 400, "Deposite"),"Working");
	    BankingDBUtil.accounts.put(Integer.parseInt(acc1.getAccountNum()), acc1);
	    BankingDBUtil.accounts.put(Integer.parseInt(acc2.getAccountNum()), acc2);
	    BankingDBUtil.ACCOUNT_NO_COUNTER=10011;
	    
	    }
@Test(expected =InvalidAccountTypeException.class)
public void testCreateAccountForInvalidAccount() throws InvalidAccountTypeException{
	
bankingservices.createAccount("Arun", "beswn", "123456781122", "8823234211", "1234", "001", "fdg", 1 ,400,"Deposite");
	}
@Test

public void testCreateAccountForValidAccount()
{Account acc= bankingservices.createAccount("Arun", "beswn", "123456781122", "8823234211", "1234", "001", "Savings", 1 ,400,"Deposite");

	Account actual =bankingservices.createAccount("Arun", "beswn", "123456781122", "8823234211", "1234", "001", "Savings", 1 ,400,"Deposite");
  Assert.assertEquals("Savings",acc.getAccountType());
}

@Test

public void testCreateAccountForInValidPin() throws InvalidPinNumberExcepition{

	bankingservices.createAccount("Arun", "beswn", "123456781122", "8823234211", "1234", "001", "Savings", 2 ,400,"Deposite");
}
@Test 
public void testCreateAccountForValidPin() {
	Account acc=bankingservices.createAccount("Arun", "beswn", "123456781122", "8823234211", "1234", "001", "Savings", 1 ,400,"Deposite");
Assert.assertEquals(1,acc.getaPIN());	


}}
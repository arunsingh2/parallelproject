package com.cg.account.beans;

public class Customer {

	
	
String cName,cAddress,cAdhaar,cPhone;


public Customer(String cName, String cAddress, String cAdhaar, String cPhone) {
	super();
	this.cName = cName;
	this.cAddress = cAddress;
	this.cAdhaar = cAdhaar;
	this.cPhone = cPhone;
}

public String getcName() {
	return cName;
}

public void setcName(String cName) {
	this.cName = cName;
}

public String getcAddress() {
	return cAddress;
}

public void setcAddress(String cAddress) {
	this.cAddress = cAddress;
}

public String getcAdhaar() {
	return cAdhaar;
}

public void setcAdhaar(String cAdhaar) {
	this.cAdhaar = cAdhaar;
}

public String getcPhone() {
	return cPhone;
}

public void setcPhone(String cPhone) {
	this.cPhone = cPhone;
}



@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	Customer other = (Customer) obj;
	if (cAddress == null) {
		if (other.cAddress != null)
			return false;
	} else if (!cAddress.equals(other.cAddress))
		return false;
	if (cAdhaar == null) {
		if (other.cAdhaar != null)
			return false;
	} else if (!cAdhaar.equals(other.cAdhaar))
		return false;
	if (cName == null) {
		if (other.cName != null)
			return false;
	} else if (!cName.equals(other.cName))
		return false;
	if (cPhone == null) {
		if (other.cPhone != null)
			return false;
	} else if (!cPhone.equals(other.cPhone))
		return false;
	return true;


}

@Override
public String toString() {
	return "Customer [cName=" + cName + ", cAddress=" + cAddress + ", cAdhaar=" + cAdhaar + ", cPhone=" + cPhone + "]";
}

}




package com.cg.account.beans;


import java.util.HashMap;
import java.util.List;
public class Account {

	
	String accountNum;
	String ifsc,accountType;
	int aPIN;
	Customer cust;
	Transaction Transactions;
	String accountStatus;

	public static HashMap<Integer, Transaction> transStatements=new HashMap<>();
	
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	public String getAccountNum()
	{
		return accountNum;
	}
	public void  setAccountNum(String accountNum)
	{
		this.accountNum=accountNum;
	}
	
	public Account(String ifsc, String accountType, int aPIN, Customer cust) {
		super();
		this.ifsc = ifsc;
		this.accountType = accountType;
		this.aPIN = aPIN;
		this.cust = cust;
	}

	public Account(String accountNum, String ifsc, String accountType, int aPIN, Customer cust)
	{super();
		this.accountNum = accountNum;
		this.ifsc = ifsc;
		this.accountType = accountType;
		this.aPIN = aPIN;
		this.cust = cust;
		
	}
	public Account(String ifsc, String accountType, int aPIN, Customer cust, Transaction transactions,String accountStatus) {
		super();
		this.ifsc = ifsc;
		this.accountType = accountType;
		this.aPIN = aPIN;
		this.cust = cust;
		Transactions = transactions;
		this.accountStatus=accountStatus;
	}
	public Account(String accountNum,String ifsc, String accountType, int aPIN, Customer cust, Transaction transactions,String accountStatus) {
		super();
		this.ifsc = ifsc;
		this.accountType = accountType;
		this.aPIN = aPIN;
		this.cust = cust;
		Transactions = transactions;
		this.accountStatus=accountStatus;
		this.accountNum=accountNum;
	}
	public Account() {
		// TODO Auto-generated constructor stub
	}
	
	public HashMap<Integer,Transaction>getTransStatements(){
		return transStatements;
	}
	public static void setTransStatements(HashMap<Integer,Transaction>transStatements) {
		Account.transStatements=transStatements;
	}
	
	
	
	public String getIfsc() {
		return ifsc;
	}
	public void setIfsc(String ifsc) {
		this.ifsc = ifsc;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public int getaPIN() {
		return aPIN;
	}
	public void setaPIN(int aPIN) {
		this.aPIN = aPIN;
	}
	public Customer getCust() {
		return cust;
	}
	public void setCust(Customer cust) {
		this.cust = cust;
	}
	public Transaction getTransactions() {
		return Transactions;
	}
	public void setTransactions(Transaction transactions) {
		Transactions = transactions;
	}
	
	
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Account other = (Account) obj;
		if (Transactions == null) {
			if (other.Transactions != null)
				return false;
		} else if (!Transactions.equals(other.Transactions))
			return false;
		if (aPIN != other.aPIN)
			return false;
		
		
		if (accountType == null) {
			if (other.accountType != null)
				return false;
		} else if (!accountType.equals(other.accountType))
			return false;
		if (cust == null) {
			if (other.cust != null)
				return false;
		} else if (!cust.equals(other.cust))
			return false;
		if (ifsc == null) {
			if (other.ifsc != null)
				return false;
		} else if (!ifsc.equals(other.ifsc))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Account [accountNum=" + accountNum + ", ifsc=" + ifsc + ", accountType=" + accountType + ", aPIN="
				+ aPIN + ", cust=" + cust + ", Transactions=" + Transactions + "]";
	}
	
	}
	
		
	
	
	


	

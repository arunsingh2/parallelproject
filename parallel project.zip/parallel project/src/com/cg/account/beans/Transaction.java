package com.cg.account.beans;

public class Transaction {
	@Override
	public String toString() {
		return "Transaction [transactionId=" + transactionId + ", amount=" + amount + ", transactionType="
				+ transactionType + ", getTransactionId()=" + getTransactionId() + ", getAmount()=" + getAmount()
				+ ", getTransactionType()=" + getTransactionType() + ", getClass()=" + getClass() + ", hashCode()="
				+ hashCode() + ", toString()=" + super.toString() + "]";
	}
	int  transactionId=1000;
	private float amount;
	String  transactionType;

	
	public Transaction(float amount, String transactionType) {
		super();
		this.amount = amount;
		this.transactionType = transactionType;
	}

	

	public void setTransactionId() {
		transactionId =(++transactionId);
	}

	public int  getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(int transactionId) {
		transactionId =++ transactionId;
	}
	public Transaction(int transactionId, float amount,String transactionType) {
		super();
		transactionId = transactionId;
		this.amount = amount;
		this.transactionType = transactionType;
	}

	public float getAmount() {
		return amount;
	}
	public void setAmount(float amount) {
		this.amount = amount;
	}
	public String getTransactionType() {
		return transactionType;
	}
	public void setTransactionType(String transactionType) {
		transactionType = transactionType;
	}

	}
